package com.employee.controller;

import java.io.File;
import java.io.FileInputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.models.Result;
import com.employee.service.PdfService;

@RestController("/")
@CrossOrigin("*")
public class PdfController {
	
	@Autowired
	private PdfService pdfService;

	@PostMapping("/save-pdf")
	public ResponseEntity<InputStreamResource> downloadPdf(@RequestBody Result result, HttpServletResponse response)
			throws Exception {

		File file = pdfService.generateTable(result);
		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
				.contentLength(file.length()).body(resource);
	}

	

}
