package com.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.employee.models.EmployeeDetails;
import com.employee.service.EmployeeService;

/**
 * @author 
 *
 */
@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;

	
	/**
	 * @param employee
	 * @return
	 */
	@GetMapping("/index")
	public ModelAndView createEmployee() {
		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setId(0);
		ModelAndView mv = new ModelAndView();
		mv.addObject("employee", employeeDetails);
		mv.setViewName("index.html");
		return mv;
	}
	

	/**
	 * @return
	 */
	@GetMapping("/")
	public String home() {
		return  "redirect:index";
	}
	
	/**
	 * @param employee
	 * @return
	 */
	@PostMapping("/result")
	public ModelAndView result(@ModelAttribute EmployeeDetails employee) {
		return employeeService.calculateResult(employee);
		
	}
	
	@GetMapping("/edit/{id}")
	public ModelAndView  editDetails(@PathVariable("id") int id) {
		return employeeService.editEmployeeDetails(id);		
	}

}



















