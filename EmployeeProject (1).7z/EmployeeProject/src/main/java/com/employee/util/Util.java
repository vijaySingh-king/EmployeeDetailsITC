package com.employee.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Util {

	/**
	 * @param str
	 * @return
	 */
	public static boolean isNullOrBlank(String str) {
		if (str == null) {
			return true;
		}
		if ("".equals(str) || str.trim().length() == 0) {
			return true;
		}
		return false;
	}

	/**
	 * start is inclusive, end is exclusive
	 * 
	 * @param value
	 * @return
	 */
	public static boolean isValueIn(double value, double start, double end) {
		if (value >= start && value < end) {
			return true;
		}
		return false;
	}
	
	/**
	 * @param value
	 * @param places
	 * @return
	 */
	public static double round(double value, int places) {
	    if (places < 0) throw new IllegalArgumentException();

	    BigDecimal bd = BigDecimal.valueOf(value);
	    bd = bd.setScale(places, RoundingMode.HALF_UP);
	    return bd.doubleValue();
	}

}
