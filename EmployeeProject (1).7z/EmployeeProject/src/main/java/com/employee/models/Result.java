package com.employee.models;

public class Result {

	private String processName;
	private String extentOfAutomation;
	private String efficiencyScore;//
	private String effectivenessScore;
	private String experienceScore;//
	private double effortSavingHours;
	private double annualSavings;
	private String currency;
	private double fteSavings;
	private double effortSavingsEquivalentToFte;

	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}



	public String getExtentOfAutomation() {
		return extentOfAutomation;
	}

	public void setExtentOfAutomation(String extentOfAutomation) {
		this.extentOfAutomation = extentOfAutomation;
	}

	public String getEfficiencyScore() {
		return efficiencyScore;
	}

	public void setEfficiencyScore(String efficiencyScore) {
		this.efficiencyScore = efficiencyScore;
	}

	public String getEffectivenessScore() {
		return effectivenessScore;
	}

	public void setEffectivenessScore(String effectivenessScore) {
		this.effectivenessScore = effectivenessScore;
	}

	public String getExperienceScore() {
		return experienceScore;
	}

	public void setExperienceScore(String experienceScore) {
		this.experienceScore = experienceScore;
	}

	public double getEffortSavingHours() {
		return effortSavingHours;
	}

	public void setEffortSavingHours(double effortSavingHours) {
		this.effortSavingHours = effortSavingHours;
	}

	public double getAnnualSavings() {
		return annualSavings;
	}

	public void setAnnualSavings(double annualSavings) {
		this.annualSavings = annualSavings;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public double getFteSavings() {
		return fteSavings;
	}

	public void setFteSavings(double fteSavings) {
		this.fteSavings = fteSavings;
	}

	public double getEffortSavingsEquivalentToFte() {
		return effortSavingsEquivalentToFte;
	}

	public void setEffortSavingsEquivalentToFte(double effortSavingsEquivalentToFte) {
		this.effortSavingsEquivalentToFte = effortSavingsEquivalentToFte;
	}

	@Override
	public String toString() {
		return "Result [processName=" + processName + ", extentOfAutomation=" + extentOfAutomation
				+ ", efficiencyScore=" + efficiencyScore + ", effectivenessScore=" + effectivenessScore
				+ ", experienceScore=" + experienceScore + ", effortSavingHours=" + effortSavingHours
				+ ", annualSavings=" + annualSavings + ", currency=" + currency + ", fteSavings=" + fteSavings
				+ ", effortSavingsEquivalentToFte=" + effortSavingsEquivalentToFte + "]";
	}

}
