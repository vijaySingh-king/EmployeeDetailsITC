package com.employee.service;

import java.util.LinkedHashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.employee.models.EmployeeDetails;
import com.employee.models.Result;
import com.employee.repository.EmployeeRepoitory;
import com.employee.util.Util;

/**
 * @author
 *
 */
@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepoitory employeeRepoitory;

	/**
	 * @param employee
	 * @return
	 */
	public ModelAndView calculateResult(EmployeeDetails employee) {

		ModelAndView mv = new ModelAndView();

		Set<String> errors = new LinkedHashSet<String>();
		boolean status = this.validateEmployeeDetails(employee, errors);

		// errors check
		if (!status) {
			mv.addObject("employee", employee);
			mv.setViewName("index");
			mv.addObject("errors", errors);
			return mv;
		}

		// update case
		if (employee.getId() != 0) {
			employeeRepoitory.save(employee);
			mv.addObject("result", this.calculateData(employee));
			mv.setViewName("result");
			mv.addObject("id", employee.getId());
			return mv;
		}

		EmployeeDetails save = employeeRepoitory.save(employee);

		mv.setViewName("result");
		mv.addObject("result", this.calculateData(employee));
		mv.addObject("id", save.getId());
		return mv;
	}

	/**
	 * @param employee
	 * @param errors
	 * @return
	 */
	private boolean validateEmployeeDetails(EmployeeDetails employee, Set<String> errors) {
		boolean isValid = true;

		if (Util.isNullOrBlank(employee.getName())) {
			isValid = false;
			errors.add("name is required");
		}
		if (Util.isNullOrBlank(employee.getEmail())) {
			isValid = false;
			errors.add("email is required");
		}
		if (Util.isNullOrBlank(employee.getContactNumber())) {
			isValid = false;
			errors.add("contact number is required");
		}


		double manualEffort = (employee.getTotalTransactionsPerMonth()
				* (employee.getMinutesTakenByOneTransaction() * 12)) / 60;
		double fteHours = employee.getResourcesInvolvedInTheProcess() * 1920;
		if (manualEffort > fteHours) {
			isValid = false;
			errors.add("Manual hours cannot be greater than actual fte hours");
		}

		return isValid;
	}

	/**
	 * @param employee
	 * @return
	 */
	private Result calculateData(EmployeeDetails employee) {
		double extentOfAutomation = (double) employee.getDataTypePercentOfStructuredData()
				+ (double) employee.getPercentOfRuleBasedTransaction() + 5
				- (double) employee.getPercentOfRuleBasedTransaction()
				+ (double) (employee.getNeedStandardisation().trim().equals("YES") ? 0 : 5)
				+ (double) (employee.getTechnicalCharacteristics().trim().equals("YES") ? 0 : 5);

		int finalExtentOfAutomation = this
				.getExtentOfAutomationPercent(this.getScoreRating((int) extentOfAutomation).trim());

		double effectivenessScore = (((double) employee.getTimeCriticality() / 5.0) * 33.0)
				+ (((double) finalExtentOfAutomation / 100.0) * 0.4 * 0.33)
				+ ((1.0 - ((double) employee.getImpactOfError() / 5.0)) * 33.0);


		String effectivenessScoreRating = String.format("%.2f", effectivenessScore);

		double effortSaving = (12 * employee.getTotalTransactionsPerMonth())
				* ((double) employee.getMinutesTakenByOneTransaction() / 60.0)
				* ((double) finalExtentOfAutomation / 100.0);

		double annualSaving = effortSaving * ((double) employee.getAnnualSalaryOfResource() / 1920.0);

		int questionsSum = employee.getQestion1() + employee.getQestion2() + employee.getQestion3()
				+ employee.getQestion4() + employee.getQestion5();
		double experienceScore = (1.0 - ((double) questionsSum / 50.0)) * 100.0;


		Result result = new Result();


		result.setProcessName(employee.getNameOfTheProcess());
		result.setExtentOfAutomation(finalExtentOfAutomation + " %");

		result.setEffectivenessScore(effectivenessScoreRating + " %");
		result.setExperienceScore(String.valueOf(experienceScore) + "%");
		result.setAnnualSavings(Util.round(annualSaving, 2));
		result.setCurrency(employee.getCurrency());

		double v = effortSaving / 1920;
		int effortSavingScore = this.calculateEffortSavingScore(v);

		result.setEffortSavingHours(effortSaving);
		result.setEffortSavingsEquivalentToFte(Util.round(v, 2));


		result.setFteSavings(Util.round(v / 2, 4));// fte savings %

		double effScore = (this.calculateEfficiencyScore(employee, effortSavingScore));
		result.setEfficiencyScore(Util.round(effScore, 2) + " %");

		return result;
	}

	/**
	 * method to calculate effort saving score
	 * 
	 * @param value
	 * @return
	 */
	private int calculateEffortSavingScore(double value) {
		if (value >= 0.0 && value <= 1.0) {
			return 1;
		} else if (value > 1.0 && value <= 2.0) {
			return 2;
		} else if (value > 2.0 && value <= 3.0) {
			return 3;
		} else if (value > 3.0 && value <= 4.0) {
			return 4;
		} else if (value > 4.0) {
			return 5;
		}

		return 0;
	}

	/**
	 * @param number
	 * @return
	 */
	private String getScoreRating(int number) {

		switch (number) {
		case 1:
		case 2:
		case 3:
			return "0%";
		case 4:
		case 5:
		case 6:
			return "0-15%";
		case 7:
		case 8:
		case 9:
			return "15-25%";
		case 10:
		case 11:
		case 12:
			return "25-50%";
		case 13:
		case 14:
		case 15:
		case 16:
			return "50-75%";
		case 17:
		case 18:
		case 19:
		case 20:
			return "75-90%";
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
			return "90-100%";
		default:
			return "0%";
		}
	}

	/**
	 * @param details
	 * @return
	 */
	private double calculateEfficiencyScore(EmployeeDetails details, double effortSaving) {
		double b = ((double) this.getPremiumnessScore(details) / 5.0);
		double EfficiencyScore = ((((effortSaving / 5.0) * 0.6) + (0.4 * (b / 5.0))) * 100.0);
		return EfficiencyScore;
	}

	/**
	 * Method to calculate premium ness score
	 * 
	 * @param details
	 * @return
	 */
	private int getPremiumnessScore(EmployeeDetails details) {

		double value = details.getAnnualSalaryOfResource();
		if (details.getCurrency().trim().equalsIgnoreCase("INR")) {

			if (Util.isValueIn(value, 0, 249600)) {
				return 1;
			}
			if (Util.isValueIn(value, 249600, 672000)) {
				return 2;
			}
			if (Util.isValueIn(value, 672000, 960000)) {
				return 3;
			}
			if (Util.isValueIn(value, 960000, 1497600)) {
				return 4;
			}
			if (Util.isValueIn(value, 1497600, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("USD")) {
			if (Util.isValueIn(value, 0, 24960)) {
				return 1;
			}
			if (Util.isValueIn(value, 24960, 57600)) {
				return 2;
			}
			if (Util.isValueIn(value, 57600, 105600)) {
				return 3;
			}
			if (Util.isValueIn(value, 105600, 144000)) {
				return 4;
			}
			if (Util.isValueIn(value, 144000, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("EURO")) {

			if (Util.isValueIn(value, 0, 19200)) {
				return 1;
			}
			if (Util.isValueIn(value, 19200, 34560)) {
				return 2;
			}
			if (Util.isValueIn(value, 34560, 53760)) {
				return 3;
			}
			if (Util.isValueIn(value, 53760, 76800)) {
				return 4;
			}
			if (Util.isValueIn(value, 76800, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("GBP")) {

			if (Util.isValueIn(value, 0, 17280)) {
				return 1;
			}
			if (Util.isValueIn(value, 17280, 30720)) {
				return 2;
			}
			if (Util.isValueIn(value, 30720, 46080)) {
				return 3;
			}
			if (Util.isValueIn(value, 46080, 57600)) {
				return 4;
			}
			if (Util.isValueIn(value, 57600, Double.MAX_VALUE)) {
				return 5;
			}

		} else if (details.getCurrency().trim().equalsIgnoreCase("AUD")) {

			if (Util.isValueIn(value, 0, 48000)) {
				return 1;
			}
			if (Util.isValueIn(value, 48000, 76800)) {
				return 2;
			}
			if (Util.isValueIn(value, 76800, 115200)) {
				return 3;
			}
			if (Util.isValueIn(value, 115200, 153600)) {
				return 4;
			}
			if (Util.isValueIn(value, 153600, Double.MAX_VALUE)) {
				return 5;
			}
		}

		return 0;

	}

	/**
	 * @param id
	 * @return
	 */
	public ModelAndView editEmployeeDetails(int id) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		mv.addObject("employee", employeeRepoitory.findById(id));
		return mv;
	}

	/**
	 * @param percent
	 * @return
	 */
	private int getExtentOfAutomationPercent(String percent) {
		switch (percent) {
		case "0%":
		case "0-15%":
			return 0;
		case "15-25%":
			return 20;
		case "25-50%":
			return 40;
		case "50-75%":
			return 60;
		case "75-90%":
			return 80;
		case "90-100%":
			return 95;
		default:
			return 0;
		}
	}
}
