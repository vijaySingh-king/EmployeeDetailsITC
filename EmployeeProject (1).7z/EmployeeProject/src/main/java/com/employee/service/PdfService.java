package com.employee.service;

import java.io.File;
import java.io.FileOutputStream;

import org.springframework.stereotype.Service;

import com.employee.models.Result;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PdfService {

	
	/**
	 * @param result
	 * @return
	 * @throws Exception
	 */
	public File generateTable(Result result) throws Exception {
		Document document = new Document();

		File f = new File("./files/Result.pdf");
		if (f.exists()) {
			f.delete();
		}
		f.createNewFile();

		FileOutputStream os = new FileOutputStream(f);

		PdfWriter.getInstance(document, os);
		document.open();
		Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0));
		Font bf12 = new Font(FontFamily.TIMES_ROMAN, 12);

		float[] columnWidths = { 5f, 5f };
		PdfPTable table = new PdfPTable(columnWidths);
		table.setWidthPercentage(90f);

		insertCell(table, "RESULT..", Element.ALIGN_CENTER, 2, bfBold12);
		insertCell(table, "", Element.ALIGN_LEFT, 2, bfBold12);

		insertCell(table, "Process Name", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, result.getProcessName(), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Extent Of Automation", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, String.valueOf(result.getExtentOfAutomation()), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Efficiency Score (%)", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, result.getEfficiencyScore(), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Effectivenes Score (%)", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, result.getEffectivenessScore(), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Experience Score (%)", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, result.getExperienceScore(), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Effort Saving Hours/year", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, String.valueOf(result.getEffortSavingHours()), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Annual Savings", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, String.valueOf(result.getAnnualSavings()), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "% FTE Savings", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, String.valueOf(result.getFteSavings()), Element.ALIGN_CENTER, 1, bf12);

		insertCell(table, "Effort Savings Equivalent to FTE", Element.ALIGN_LEFT, 1, bf12);
		insertCell(table, String.valueOf(result.getEffortSavingsEquivalentToFte()), Element.ALIGN_CENTER, 1, bf12);

		Paragraph paragraph = new Paragraph();
		paragraph.add(table);
		document.add(paragraph);

		document.close();
		os.flush();
		os.close();

		File file = new File("./files/Result.pdf");
		return file;
	}

	/**
	 * @param table
	 * @param text
	 * @param align
	 * @param colspan
	 * @param font
	 */
	private void insertCell(PdfPTable table, String text, int align, int colspan, Font font) {

		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		cell.setHorizontalAlignment(align);
		cell.setColspan(colspan);
		if (text.trim().equalsIgnoreCase("")) {
			cell.setMinimumHeight(10f);
		}
		table.addCell(cell);

	}
}
