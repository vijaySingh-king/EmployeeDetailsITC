
$("#toBeChanged").css({ "height": "0px", "overflow": "hidden" });
$("#showHideOption").change(function() {
	if ($(this).val() == "YES") {
		$("#toBeChanged").css({ "height": "", "overflow": "" });
	}
	else {
		$("#toBeChanged").css({ "height": "0px", "overflow": "hidden" });
	}
});

function getData() {
	return {
		"processName": document.getElementById("processName").value,
		"extentOfAutomation": document.getElementById("extentOfAutomation").value,
		"efficiencyScore": document.getElementById("efficiencyScore").value,
		"effectivenessScore": document.getElementById("effectivenessScore").value,
		"experienceScore": document.getElementById("experienceScore").value,
		"effortSavingHours": document.getElementById("effortSavingHours").value,
		"annualSavings": document.getElementById("annualSavings").value,
		"currency": document.getElementById("currency").value,
		"fteSavings": document.getElementById("fteSavings").value,
		"effortSavingsEquivalentToFte": document.getElementById("effortSavingsEquivalentToFte").value,
	}

}

/*
$("#saveAsPdf").click(downloadFile());*/

function downloadFile(){

fetch('/save-pdf', {
    body: JSON.stringify(getData()),
    method: 'POST',
    headers: {
        'Content-Type': 'application/json; charset=utf-8'
    },
})
.then(response => response.blob())
.then(response => {
    const blob = new Blob([response], {type: 'application/pdf'});
    const downloadUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = downloadUrl;
    a.download = "result.pdf"; 
    document.body.appendChild(a);
    a.click();
})
	
}



function changeParentvalue(){
			document.getElementById( "child-select").value = document.getElementById( "parent-select").value;
	}
	




$("#customdepartment").css({ "height": "0px", "overflow": "hidden" });
$("#customdepartmentset").change(function() {
	if ($(this).val() == "Others") {
		$("#customdepartment").css({ "height": "", "overflow": "" });
	}
	else {
		$("#customdepartment").css({ "height": "0px", "overflow": "hidden" });
	}
});



